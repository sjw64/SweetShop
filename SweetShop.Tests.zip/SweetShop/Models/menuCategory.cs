﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SweetShop.Models
{
    public class menuCategory
    {
        public int menuCategoryID { get; set; }

        public string categoryType { get; set; }

        public int size { get; set; }

        public double categoryPrice { get; set; }

        public virtual menuItem menuItem { get; set; }
    }
}