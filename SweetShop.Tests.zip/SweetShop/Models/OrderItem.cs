﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace SweetShop.Models
{
    public class OrderItem
    {
        [Key]
        public int OrderItemID { get; set; }

        [Display(Name = "Order Number")]
        public double orderID { get; set; }

        [Display(Name = "Item Name")]
        public int ItemID { get; set; }

        [Range(0,100)]
        public int Quantity { get; set; }

        [Range(1, 18)]
        [Display(Name = "Item Size")]
        public int size { get; set; }

        public virtual menuItem Item { get; set; }

        public virtual Order orders { get; set; }
    }
}