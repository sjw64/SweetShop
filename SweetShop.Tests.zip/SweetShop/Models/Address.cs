﻿using System;

namespace SweetShop.Models
{
    public class Address 
    {
        public int ID { get; set; }

        public string LastName { get; set; }

        public string FirstName { get; set; }

        public string street { get; set; }

        public string city { get; set; }

        public string state { get; set; }

        public int zipcode { get; set; }

        public bool saveAddress { get; set; }

        public bool billingAddress { get; set; }

        public bool deliveryAddress { get; set; }

    }
}