﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace SweetShop.Models
{
    public class menuItem
    {
        [Key]
        public int itemID { get; set; }

        public string itemName { get; set; }

        public string itemDescription { get; set; }

        public string CategoryType { get; set; }

        public virtual ICollection<menuCategory> Categories { get; set; }

    }
}