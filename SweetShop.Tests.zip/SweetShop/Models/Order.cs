﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace SweetShop.Models
{
    public class Order
    {
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        [Display(Name = "Order Number")]
        public double orderID { get; set; }

        public virtual ICollection<OrderItem> orderItems { get; set; }

        public double subtotal { get; set; }

        public double tax { get; set; }

        public double deliveryCharge { get; set; }

        public double total { get; set; }

        public int deliveryID { get; set; }

        public int billingID { get; set; }

        public bool delivery { get; set; }

        public int? zipcode { get; set; }

        public bool firsttime { get; set; }

        public int? rating { get; set; }
        
        public virtual Address address { get; set; }

    }
}