﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SweetShop.DAL;
using SweetShop.Models;

namespace SweetShop.Controllers
{
    [RequireHttps]
    public class HomeController : Controller
    {
        private ShopContext db = new ShopContext();

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Chat()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "About the Sweet Shop.";

            return View();
        }

        //[Authorize]
        public ActionResult Contact()
        {
            ViewBag.Message = "Contact us anytime!";

            return View();
        }

        public ActionResult Menu()
        {
            ViewBag.Message = "Our Menu.";

            return View(db.Items.ToList());
        }

        public ActionResult Order(int? ItemID, double? orderID)
        {
            if (orderID == null)
            {
                string dateID = DateTime.Now.ToString("yyyyMMddHHmmss");
                ViewBag.orderID = Convert.ToDouble(dateID);
            }
            ViewBag.Message = "Orders placed here.";
            ViewBag.ItemID = new SelectList(db.Items, "itemID", "itemName");
            return View();
        }

        // POST: Add Item/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Add([Bind(Include = "OrderItemID,orderID,ItemID,Quantity,size")] OrderItem ordItems)
        {
            if (ModelState.IsValid)
            {
                db.Orditems.Add(ordItems);
                db.SaveChanges();
                return RedirectToAction("Order");
            }

            return View(ordItems);
        }

        // POST: Create Order/Go To Checkout
        public ActionResult Checkout([Bind(Include = "OrderItemID,orderID,ItemID,Quantity,size")] OrderItem ordItems)
        {
            if (ModelState.IsValid)
            {
                db.Orditems.Add(ordItems);
                db.SaveChanges();
                double ItemID = ViewBag.ItemID;
                return RedirectToAction("OrderItem/Index", new { id = ItemID });
            }

            return View(ordItems);
        }
    }
}
