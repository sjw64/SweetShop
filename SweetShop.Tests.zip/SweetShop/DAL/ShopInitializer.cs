﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using SweetShop.Models;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.AspNet.Identity;

namespace SweetShop.DAL
{
    public class ShopInitializer : System.Data.Entity.DropCreateDatabaseIfModelChanges<ShopContext>
    {
        protected override void Seed(ShopContext context)
        {
            var Categories = new List<menuCategory>
            {
            new menuCategory{categoryType="Signature",size=6,categoryPrice=30.00},
            new menuCategory{categoryType="Signature",size=9,categoryPrice=40.00},
            new menuCategory{categoryType="Signature",size=4,categoryPrice=50.00},
            new menuCategory{categoryType="Signature",size=2,categoryPrice=70.00},
            new menuCategory{categoryType="Signature",size=1,categoryPrice=2.50},
            new menuCategory{categoryType="Daily",size=6,categoryPrice=25.00},
            new menuCategory{categoryType="Daily",size=9,categoryPrice=35.00},
            new menuCategory{categoryType="Daily",size=4,categoryPrice=45.00},
            new menuCategory{categoryType="Daily",size=2,categoryPrice=60.00},
            new menuCategory{categoryType="Daily",size=1,categoryPrice=2.00},
            new menuCategory{categoryType="Pie",size=9,categoryPrice=25.00},
            new menuCategory{categoryType="Cheesecake",size=9,categoryPrice=35.00},
            new menuCategory{categoryType="Specialty",size=9,categoryPrice=40.00},
            new menuCategory{categoryType="Chocolates",size=8,categoryPrice=12.00},
            new menuCategory{categoryType="Chocolates",size=12,categoryPrice=18.00},
            new menuCategory{categoryType="Chocolates",size=18,categoryPrice=24.00},
            new menuCategory{categoryType="Champange",size=1,categoryPrice=20.00},
            new menuCategory{categoryType="Cookies",size=1,categoryPrice=1.50},
            new menuCategory{categoryType="Eclairs",size=1,categoryPrice=2.50},
            new menuCategory{categoryType="Muffins",size=1,categoryPrice=2.00},
            };

            Categories.ForEach(s => context.Categories.Add(s));
            context.SaveChanges();

            var Items = new List<menuItem>
            {
            new menuItem{itemName="Pink Champange",itemDescription="Cake or cupcake",CategoryType="Signature"},
            new menuItem{itemName="German Chocolate",itemDescription="Cake or cupcake",CategoryType="Signature"},
            new menuItem{itemName="Chocolate Peanut Butter",itemDescription="Cake or cupcake",CategoryType="Signature"},
            new menuItem{itemName="Carrot",itemDescription="Cake or cupcake",CategoryType="Signature"},
            new menuItem{itemName="Chocolate",itemDescription="Cake or cupcake",CategoryType="Daily"},
            new menuItem{itemName="Vanilla",itemDescription="Cake or cupcake",CategoryType="Daily"},
            new menuItem{itemName="Red Velvet",itemDescription="Cake or cupcake",CategoryType="Daily"},
            new menuItem{itemName="Lemon",itemDescription="Cake or cupcake",CategoryType="Daily"},
            new menuItem{itemName="Apple",itemDescription="Pie",CategoryType="Pie"},
            new menuItem{itemName="Cherry",itemDescription="Pie",CategoryType="Pie"},
            new menuItem{itemName="Marionberry",itemDescription="Pie",CategoryType="Pie"},
            new menuItem{itemName="Peach",itemDescription="Pie",CategoryType="Pie"},
            new menuItem{itemName="Strawberry Rhubarb",itemDescription="Pie",CategoryType="Pie"},
            new menuItem{itemName="Pecan",itemDescription="Pie",CategoryType="Pie"},
            new menuItem{itemName="Pumpkin",itemDescription="Pie",CategoryType="Pie"},
            new menuItem{itemName="Sweet Potato",itemDescription="Pie",CategoryType="Pie"},
            new menuItem{itemName="Lemon Meringue",itemDescription="Pie",CategoryType="Pie"},
            new menuItem{itemName="Coconut Cream",itemDescription="Pie",CategoryType="Pie"},
            new menuItem{itemName="Banana Cream",itemDescription="Pie",CategoryType="Pie"},
            new menuItem{itemName="Chocolate Cream",itemDescription="Pie",CategoryType="Pie"},
            new menuItem{itemName="Classic",itemDescription="Cheescake",CategoryType="Cheescake"},
            new menuItem{itemName="Three Berry",itemDescription="Cheescake",CategoryType="Cheescake"},
            new menuItem{itemName="Chocolate",itemDescription="Cheescake",CategoryType="Cheescake"},
            new menuItem{itemName="Lemon Blueberry",itemDescription="Cheescake",CategoryType="Cheescake"},
            new menuItem{itemName="Pumpkin",itemDescription="Cheescake",CategoryType="Cheescake"},
            new menuItem{itemName="White Chocolate Marionberry",itemDescription="Cheescake",CategoryType="Cheescake"},
            new menuItem{itemName="Pralines and Cream",itemDescription="Cheescake",CategoryType="Specialty"},
            new menuItem{itemName="Chocolate Peanut Butter Cup",itemDescription="Cheescake",CategoryType="Specialty"},
            new menuItem{itemName="Grasshopper",itemDescription="Cheescake",CategoryType="Specialty"},
            new menuItem{itemName="Fudge",itemDescription="Fudge",CategoryType="Chocolates"},
            new menuItem{itemName="Chocolate covered Strawberries",itemDescription="Chocolates",CategoryType="Chocolates"},
            new menuItem{itemName="Toffee",itemDescription="Chocolates",CategoryType="Chocolates"},
            new menuItem{itemName="Truffles",itemDescription="Chocolates",CategoryType="Chocolates"},
            new menuItem{itemName="Champange",itemDescription="Champange",CategoryType="Champange"},
            new menuItem{itemName="Chocolate Chip",itemDescription="Cookies",CategoryType="Cookies"},
            new menuItem{itemName="Oatmeal Raisin",itemDescription="Cookies",CategoryType="Cookies"},
            new menuItem{itemName="White Chocolate Macadamia Nut",itemDescription="Cookies",CategoryType="Cookies"},
            new menuItem{itemName="Shortbread",itemDescription="Cookies",CategoryType="Cookies"},
            new menuItem{itemName="Snickerdoodles",itemDescription="Cookies",CategoryType="Cookies"},
            new menuItem{itemName="Lemon Bars",itemDescription="Cookies",CategoryType="Cookies"},
            new menuItem{itemName="Brownies",itemDescription="Cookies",CategoryType="Cookies"},
            new menuItem{itemName="Blondies",itemDescription="Cookies",CategoryType="Cookies"},
            new menuItem{itemName="Fruit Tarts",itemDescription="Tarts",CategoryType="Eclairs"},
            new menuItem{itemName="Eclairs",itemDescription="Eclairs",CategoryType="Eclairs"},
            new menuItem{itemName="Cannoli",itemDescription="Cannoli",CategoryType="Eclairs"},
            new menuItem{itemName="Cinnamon Streusal",itemDescription="Muffins",CategoryType="Muffins"},
            new menuItem{itemName="Blueberry",itemDescription="Muffins",CategoryType="Muffins"},
            new menuItem{itemName="Chocolate Chip",itemDescription="Muffins",CategoryType="Muffins"},
            new menuItem{itemName="Banana Nut",itemDescription="Muffins",CategoryType="Muffins"},
            new menuItem{itemName="Lemon Poppy Seed",itemDescription="Muffins",CategoryType="Muffins"},
            new menuItem{itemName="Raspberry Orange",itemDescription="Muffins",CategoryType="Muffins"},
            new menuItem{itemName="Original Scone",itemDescription="Scones",CategoryType="Muffins"},
            new menuItem{itemName="Raspberry Scone",itemDescription="Scones",CategoryType="Muffins"},
            new menuItem{itemName="Pumpkin Scone",itemDescription="Scones",CategoryType="Muffins"},
            new menuItem{itemName="Bluberry Scone",itemDescription="Scones",CategoryType="Muffins"}
            };
            Items.ForEach(s => context.Items.Add(s));
            context.SaveChanges();

            var Orders = new List<Order>
            {
            new Order{orderID=20170301112050 },
            new Order{orderID=20170301142452 },
            new Order{orderID=20170301174020 },
            new Order{orderID=20170302102250 },
            new Order{orderID=20170302120220 }
            };
            Orders.ForEach(s => context.orders.Add(s));
            context.SaveChanges();

            var addresses = new List<Address>
            {
            new Address{LastName="Wentworth",FirstName="Sandi",street="123 Main St",city="Tacoma",state="WA",zipcode=98404,saveAddress=true, billingAddress=true, deliveryAddress=true}
            };
            addresses.ForEach(s => context.Addresses.Add(s));
            context.SaveChanges();


            var orderitems = new List<OrderItem>
            {
            new OrderItem{ orderID=20170301112050, ItemID=31, Quantity=1, size=8 },
            new OrderItem{ orderID=20170301112050, ItemID=34, Quantity=1, size=1 },
            new OrderItem{ orderID=20170301142452, ItemID=1, Quantity=1, size=6 },
            new OrderItem{ orderID=20170301174020, ItemID=27, Quantity=1, size=9 },
            new OrderItem{ orderID=20170302102250, ItemID=55, Quantity=12, size=1 },
            new OrderItem{ orderID=20170302120220, ItemID=13, Quantity=1, size=9 },
            };
            orderitems.ForEach(s => context.Orditems.Add(s));
            context.SaveChanges();

        }
    }
    public class ApplicationDbInitializer : DropCreateDatabaseIfModelChanges<ApplicationDbContext>
    {

        protected override void Seed(ApplicationDbContext context)
        {
            InitializeIdentityForEF(context);
            base.Seed(context);
        }


        public static void InitializeIdentityForEF(ApplicationDbContext db)
        {
            var userManager = HttpContext
                .Current.GetOwinContext()
                .GetUserManager<ApplicationUserManager>();

           // var roleManager = HttpContext.Current
             //   .GetOwinContext()
               // .Get<ApplicationRoleManager>();

            const string name = "admin@admin.com";
            const string password = "Admin@123456";
           // const string roleName = "Admin";

            //Create Role Admin if it does not exist
           // //var role = roleManager.FindByName(roleName);
           // if (role == null)
          //  {
    //            role = new IdentityRole(roleName);
     //           var roleresult = roleManager.Create(role);
     //       }

            var user = userManager.FindByName(name);
            if (user == null)
            {
                user = new ApplicationUser { UserName = name, Email = name };
                var result = userManager.Create(user, password);
                result = userManager.SetLockoutEnabled(user.Id, false);
            }

            // Add user admin to Role Admin if not already added
            //var rolesForUser = userManager.GetRoles(user.Id);
          //  if (!rolesForUser.Contains(role.Name))
          //  {
           //     var result = userManager.AddToRole(user.Id, role.Name);
        //    }
        }
    }
}

