﻿using SweetShop.Models;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Linq;
using System.Web;

namespace SweetShop.DAL
{
    public class ShopContext : DbContext
    {
        public ShopContext() : base("ShopContext")
            {
            }

            public DbSet<menuCategory> Categories { get; set; }
            public DbSet<menuItem> Items { get; set; }
            public DbSet<Address> Addresses { get; set; }
            public DbSet<OrderItem> Orditems { get; set; }
            public DbSet<Order> orders { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
            {
                modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
            }
        }
}