namespace SweetShop.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Address",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        LastName = c.String(),
                        FirstName = c.String(),
                        street = c.String(),
                        city = c.String(),
                        state = c.String(),
                        zipcode = c.Int(nullable: false),
                        saveAddress = c.Boolean(nullable: false),
                        billingAddress = c.Boolean(nullable: false),
                        deliveryAddress = c.Boolean(nullable: false),
                    })
                .PrimaryKey(t => t.ID);
            
            CreateTable(
                "dbo.menuCategory",
                c => new
                    {
                        menuCategoryID = c.Int(nullable: false, identity: true),
                        categoryType = c.String(),
                        size = c.Int(nullable: false),
                        categoryPrice = c.Double(nullable: false),
                        menuItem_itemID = c.Int(),
                    })
                .PrimaryKey(t => t.menuCategoryID)
                .ForeignKey("dbo.menuItem", t => t.menuItem_itemID)
                .Index(t => t.menuItem_itemID);
            
            CreateTable(
                "dbo.menuItem",
                c => new
                    {
                        itemID = c.Int(nullable: false, identity: true),
                        itemName = c.String(),
                        itemDescription = c.String(),
                        CategoryType = c.String(),
                    })
                .PrimaryKey(t => t.itemID);
            
            CreateTable(
                "dbo.OrderItem",
                c => new
                    {
                        OrderItemID = c.Int(nullable: false, identity: true),
                        orderID = c.Double(nullable: false),
                        ItemID = c.Int(nullable: false),
                        Quantity = c.Int(nullable: false),
                        size = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.OrderItemID)
                .ForeignKey("dbo.menuItem", t => t.ItemID, cascadeDelete: true)
                .ForeignKey("dbo.Order", t => t.orderID, cascadeDelete: true)
                .Index(t => t.orderID)
                .Index(t => t.ItemID);
            
            CreateTable(
                "dbo.Order",
                c => new
                    {
                        orderID = c.Double(nullable: false),
                        subtotal = c.Double(nullable: false),
                        tax = c.Double(nullable: false),
                        deliveryCharge = c.Double(nullable: false),
                        total = c.Double(nullable: false),
                        deliveryID = c.Int(nullable: false),
                        billingID = c.Int(nullable: false),
                        delivery = c.Boolean(nullable: false),
                        zipcode = c.Int(),
                        firsttime = c.Boolean(nullable: false),
                        rating = c.Int(),
                        address_ID = c.Int(),
                    })
                .PrimaryKey(t => t.orderID)
                .ForeignKey("dbo.Address", t => t.address_ID)
                .Index(t => t.address_ID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.OrderItem", "orderID", "dbo.Order");
            DropForeignKey("dbo.Order", "address_ID", "dbo.Address");
            DropForeignKey("dbo.OrderItem", "ItemID", "dbo.menuItem");
            DropForeignKey("dbo.menuCategory", "menuItem_itemID", "dbo.menuItem");
            DropIndex("dbo.Order", new[] { "address_ID" });
            DropIndex("dbo.OrderItem", new[] { "ItemID" });
            DropIndex("dbo.OrderItem", new[] { "orderID" });
            DropIndex("dbo.menuCategory", new[] { "menuItem_itemID" });
            DropTable("dbo.Order");
            DropTable("dbo.OrderItem");
            DropTable("dbo.menuItem");
            DropTable("dbo.menuCategory");
            DropTable("dbo.Address");
        }
    }
}
